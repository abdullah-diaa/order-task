<x-filament::page>
      <!-- Display the custom message here -->

    <!-- You can also add any other content or widgets -->
</x-filament::page>
